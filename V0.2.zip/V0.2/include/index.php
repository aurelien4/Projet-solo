<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form>
	<label>Put your file here</label>
	<input type="file" name="json">
</form>
</body>
</html>