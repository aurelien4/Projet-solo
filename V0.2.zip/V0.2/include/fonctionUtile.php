<?php 
function go($name){
	header('location:'. $name);
 }
?>
