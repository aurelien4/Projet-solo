
<a id="editer" class="btn btn-default" href="EditeArticle.php?billet=<?php echo $data['ID'] ?>">Editer</a>
<a id="supr" class="btn btn-default" href="suprArticleSQL.php?billet=<?php echo $data['ID'] ?>">Supprimer</a>
