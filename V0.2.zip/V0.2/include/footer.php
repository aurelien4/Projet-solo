<footer class="footer">
<div class="container">
	<div class="row">
		<div class="col-sm-offset-8">
			<a href="contact.php" class="btn btn-warning">contact</a>
		</div>
	</div>
</div>
</footer>